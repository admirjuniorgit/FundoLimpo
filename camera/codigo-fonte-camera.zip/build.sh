#!/bin/bash
set -e
for arch in x86_64 i686; do
  CXX=$arch-w64-mingw32-g++
  out=build/$arch; mkdir -p $out
  objs=""
  for f in $(ls src/baseclasses/*.cpp | grep -v winutil) src/softcamcore/*.cpp src/softcam/softcam.cpp; do
    o=$out/$(echo $f | tr '/' '_').o
    $CXX -c -O2 -std=c++17 -DWIN32 -DNDEBUG -D_CRT_SECURE_NO_WARNINGS -DUNICODE -D_UNICODE \
      -include salfix.h -Ishim -Isrc -Isrc/softcam -Isrc/baseclasses -fpermissive -w $f -o $o
    objs="$objs $o"
  done
  $CXX -shared -o $out/fundolimpo_cam.dll $objs src/softcam/softcam.def \
    -static -static-libgcc -static-libstdc++ \
    -lstrmiids -lwinmm -lole32 -loleaut32 -luuid -luser32 -lgdi32 -ladvapi32 -lshell32 \
    -Wl,--enable-stdcall-fixup
  echo "OK $arch"
done
