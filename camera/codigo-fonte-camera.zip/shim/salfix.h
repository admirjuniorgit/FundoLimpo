#pragma once
#ifdef __cplusplus
#include <algorithm>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <tuple>
#include <utility>
#include <condition_variable>
#endif
#include <sal.h>
#undef __control_entrypoint
#define __control_entrypoint(...)
#undef __deref_in
#define __deref_in
#undef __deref_inout_opt
#define __deref_inout_opt
#undef __deref_out
#define __deref_out
#undef __deref_out_opt
#define __deref_out_opt
#undef __deref_out_range
#define __deref_out_range(...)
#undef __field_ecount_opt
#define __field_ecount_opt(...)
#undef __format_string
#define __format_string(...)
#undef __in
#define __in
#undef __in_bcount
#define __in_bcount(...)
#undef __in_bcount_opt
#define __in_bcount_opt(...)
#undef __in_ecount
#define __in_ecount(...)
#undef __in_opt
#define __in_opt
#undef __inout
#define __inout
#undef __inout_ecount_full
#define __inout_ecount_full(...)
#undef __inout_opt
#define __inout_opt
#undef __out
#define __out
#undef __out_bcount
#define __out_bcount(...)
#undef __out_ecount
#define __out_ecount(...)
#undef __out_ecount_part
#define __out_ecount_part(...)
#undef __out_opt
#define __out_opt
#undef __out_range
#define __out_range(...)
#undef __success
#define __success(...)
#ifndef AM_NOVTABLE
#define AM_NOVTABLE
#endif
/* macros do amvideo.h do Windows SDK que o MinGW não traz */
#ifndef WIDTHBYTES
#define WIDTHBYTES(bits) ((DWORD)(((bits)+31) & (~31)) / 8)
#endif
#ifndef DIBWIDTHBYTES
#define DIBWIDTHBYTES(bi) (DWORD)WIDTHBYTES((DWORD)(bi).biWidth * (DWORD)(bi).biBitCount)
#endif
#ifndef _DIBSIZE
#define _DIBSIZE(bi) (DIBWIDTHBYTES(bi) * (DWORD)(bi).biHeight)
#endif
#ifndef DIBSIZE
#define DIBSIZE(bi) ((bi).biHeight < 0 ? (-1)*(_DIBSIZE(bi)) : _DIBSIZE(bi))
#endif
#ifndef SIZE_PREHEADER
#define SIZE_PREHEADER (FIELD_OFFSET(VIDEOINFOHEADER,bmiHeader))
#endif
#ifndef SIZE_MASKS
#define SIZE_MASKS (iMASK_COLORS * sizeof(DWORD))
#endif
#ifndef PALETTISED
#define PALETTISED(pbmi) ((pbmi)->bmiHeader.biBitCount <= iPALETTE)
#endif
#ifndef TRUECOLOR
#define TRUECOLOR(pbmi) ((TRUECOLORINFO *)(((LPBYTE)&((pbmi)->bmiHeader)) + (pbmi)->bmiHeader.biSize))
#endif
#ifndef COLORS
#define COLORS(pbmi) ((RGBQUAD *)(((LPBYTE)&((pbmi)->bmiHeader)) + (pbmi)->bmiHeader.biSize))
#endif
#ifndef BITMASKS
#define BITMASKS(pbmi) ((DWORD *)(((LPBYTE)&((pbmi)->bmiHeader)) + (pbmi)->bmiHeader.biSize))
#endif
#ifndef HEADER
#define HEADER(pVideoInfo) (&(((VIDEOINFOHEADER *) (pVideoInfo))->bmiHeader))
#endif
#ifndef PALETTE_ENTRIES
#define PALETTE_ENTRIES(pv) ((DWORD)1 << (pv)->bmiHeader.biBitCount)
#endif
#ifndef SIZE_PALETTE
#define SIZE_PALETTE (iPALETTE_COLORS * sizeof(RGBQUAD))
#endif
#ifndef iRED
#define iRED 0
#define iGREEN 1
#define iBLUE 2
#endif
#ifndef iMAXBITS
#define iMAXBITS 8
#endif
#define BC_MIN(a,b) (((a)<(b))?(a):(b))
#define BC_MAX(a,b) (((a)>(b))?(a):(b))
